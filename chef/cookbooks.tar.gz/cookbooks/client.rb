cookbook_path File.dirname(File.expand_path(__FILE__))

