# Application_Git Changelog

## v1.1.0

* [#2](https://github.com/poise/application_git/issues/2) – Inherit user and group values from the parent `application` resource.
* [#3](https://github.com/poise/application_git/issues/3) – Fix usage with users created during the current Chef run.

## v1.0.0

* Initial release.
